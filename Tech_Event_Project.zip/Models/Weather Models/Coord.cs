﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WeatherProject.Models
{
    public class Coord
    {
        public float lat { get; set; }
        public float lon { get; set; }
    }
}