﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WeatherProject.Models
{
    public class Sys
    {
        public string pod { get; set; }
    }
}