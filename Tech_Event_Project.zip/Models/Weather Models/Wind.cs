﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WeatherProject.Models
{
    public class Wind
    {
        public float speed { get; set; }
        public float deg { get; set; }
        public float gust { get; set; }
    }
}